(() => {
  const tenantId = 'ten_local_sample';
  const userId = 'usr_local_sample';
  const apiUrl = `${window.location.origin}/local-fixture`;
  const encode = value => btoa(JSON.stringify(value)).replaceAll('=', '').replaceAll('+', '-').replaceAll('/', '_');
  const jwt = `${encode({ alg: 'none' })}.${encode({ tenantId, userId, sub: userId })}.fixture`;
  const status = document.getElementById('status');
  const preferred = new URLSearchParams(window.location.search).get('lang') || document.documentElement.dataset.kitLocale || navigator.language || 'en-US';
  const locale = window.AISupportWidget?.localization?.(preferred);
  const copy = locale?.messages ?? {};
  if (locale) {
    if (locale.locale !== document.documentElement.dataset.kitLocale) {
      document.title = copy.sampleWorkspace;
      document.querySelector('main section')?.setAttribute('aria-label', copy.sampleImport);
    }
    document.documentElement.lang = locale.locale;
    document.documentElement.dir = locale.dir;
    document.querySelectorAll('[data-copy]').forEach(element => {
      if (copy[element.dataset.copy]) element.textContent = copy[element.dataset.copy];
    });
  }
  const context = {
    userState: { tenantId, userId, roles: ['member'], plan: 'standard', featuresEnabled: [], entities: [], activeErrors: [], limitsReached: [] },
    userHistory: { windowHours: 24, events: [] },
    userLogs: { recentRequests: [], jobs: [], errors: [] },
  };
  const time = '2026-01-12T14:08:00Z';
  const caseData = { id: 'cas_sample', tenantId, userId, status: 'active', snapshotId: 'scs_sample', createdAt: time, updatedAt: time, resolvedAt: null, messageCount: 2, feedback: null };
  const reply = { id: 'msg_sample', caseId: caseData.id, role: 'assistant', content: copy.sampleAnswer ?? "匯入在 customers.csv 的第 42 行停止。該行的電子郵件欄位是空的。請新增遺漏的電子郵件，然後再次上傳 CSV。", actions: [], evidence: [{ type: 'job_id', label: copy.sampleImport ?? "匯入", value: 'import_1042' }, { type: 'error_code', label: copy.sampleError ?? "錯誤", value: 'INVALID_EMAIL' }, { type: 'timestamp', label: copy.sampleTime ?? "失敗於", value: time }], confidence: null, createdAt: time };
  let messages = [];
  const originalFetch = window.fetch.bind(window);
  // 此範例在其自己的視窗中執行。只有其合成請求會被攔截。
  window.fetch = async (resource, options) => {
    const url = new URL(typeof resource === 'string' ? resource : resource.url, window.location.href);
    if (url.origin !== window.location.origin || !url.pathname.startsWith('/local-fixture/api/')) return originalFetch(resource, options);
    if (url.pathname === '/local-fixture/api/cases' || url.pathname.endsWith('/messages')) {
      const body = JSON.parse(options.body);
      messages = [...messages, { ...reply, id: `msg_local_${messages.length}`, role: 'user', content: body.message ?? body.content, evidence: [] }, reply];
      return Response.json(url.pathname.endsWith('/messages') ? { message: reply } : { case: caseData, snapshot: { id: caseData.snapshotId }, aiMessage: reply });
    }
    if (url.pathname.endsWith('/cas_sample')) return Response.json({ case: caseData, messages });
    if (url.pathname.endsWith('/suggestions')) return Response.json({ id: 'idea_sample' }, { status: 201 });
    return Response.json({ ok: true });
  };
  let widget;
  function mount() {
    if (typeof window.AISupportWidget?.init !== 'function') {
      status.textContent = "小工具腳本無法載入。檢查 SDK URL 並重新載入頁面。";
      return;
    }
    widget = window.AISupportWidget.init({ apiUrl, tenantKey: tenantId, jwt, context, theme: 'light', locale: locale?.locale });
    document.getElementById('open').disabled = false;
    document.getElementById('reset').disabled = false;
  }
  document.getElementById('open').addEventListener('click', () => { void widget?.open(); });
  document.getElementById('reset').addEventListener('click', () => {
    widget?.destroy();
    messages = [];
    mount();
    if (widget) status.textContent = copy.sampleResetDone ?? "範例已重設。";
  });
  mount();
})();
