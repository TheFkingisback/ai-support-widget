# AI Support — kit v3 / SDK 0.2.2
Leia GUIA.md e configure backend.env.example no ambiente privado do seu aplicativo.
O operador cadastra o tenant; seu administrador configura credenciais e MCP no painel.
Nenhum segredo utilizável está incluído. Não use valores de exemplo em produção.
Execute `node --test examples.test.mjs` com Node 20+. Os testes usam mocks.
Sirva o SDK fixado no caminho usado pelo widget-controller.mjs e implemente os callbacks autenticados do aplicativo.
Preencha ACEITE.md após testar resposta real, contexto, isolamento, renovação e logout.
Documentação navegável: https://support-ai.pontes.uk/developers
