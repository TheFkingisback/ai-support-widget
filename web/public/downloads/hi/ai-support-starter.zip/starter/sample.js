(() => {
  const tenantId = 'ten_local_sample';
  const userId = 'usr_local_sample';
  const apiUrl = `${window.location.origin}/local-fixture`;
  const encode = value => btoa(JSON.stringify(value)).replaceAll('=', '').replaceAll('+', '-').replaceAll('/', '_');
  const jwt = `${encode({ alg: 'none' })}.${encode({ tenantId, userId, sub: userId })}.fixture`;
  const status = document.getElementById('status');
  const preferred = new URLSearchParams(window.location.search).get('lang') || document.documentElement.dataset.kitLocale || navigator.language || 'en-US';
  const locale = window.AISupportWidget?.localization?.(preferred);
  const copy = locale?.messages ?? {};
  if (locale) {
    if (locale.locale !== document.documentElement.dataset.kitLocale) {
      document.title = copy.sampleWorkspace;
      document.querySelector('main section')?.setAttribute('aria-label', copy.sampleImport);
    }
    document.documentElement.lang = locale.locale;
    document.documentElement.dir = locale.dir;
    document.querySelectorAll('[data-copy]').forEach(element => {
      if (copy[element.dataset.copy]) element.textContent = copy[element.dataset.copy];
    });
  }
  const context = {
    userState: { tenantId, userId, roles: ['member'], plan: 'standard', featuresEnabled: [], entities: [], activeErrors: [], limitsReached: [] },
    userHistory: { windowHours: 24, events: [] },
    userLogs: { recentRequests: [], jobs: [], errors: [] },
  };
  const time = '2026-01-12T14:08:00Z';
  const caseData = { id: 'cas_sample', tenantId, userId, status: 'active', snapshotId: 'scs_sample', createdAt: time, updatedAt: time, resolvedAt: null, messageCount: 2, feedback: null };
  const reply = { id: 'msg_sample', caseId: caseData.id, role: 'assistant', content: copy.sampleAnswer ?? "आयात customers.csv की पंक्ति 42 पर रुक गया। उस पंक्ति पर ईमेल कॉलम खाली है। लापता ईमेल जोड़ें, फिर CSV को फिर से अपलोड करें।", actions: [], evidence: [{ type: 'job_id', label: copy.sampleImport ?? "आयात", value: 'import_1042' }, { type: 'error_code', label: copy.sampleError ?? "त्रुटि", value: 'INVALID_EMAIL' }, { type: 'timestamp', label: copy.sampleTime ?? "विफल", value: time }], confidence: null, createdAt: time };
  let messages = [];
  const originalFetch = window.fetch.bind(window);
  // यह नमूना अपनी विंडो में चलता है। केवल इसके सिंथेटिक अनुरोधों को इंटरसेप्ट किया जाता है।
  window.fetch = async (resource, options) => {
    const url = new URL(typeof resource === 'string' ? resource : resource.url, window.location.href);
    if (url.origin !== window.location.origin || !url.pathname.startsWith('/local-fixture/api/')) return originalFetch(resource, options);
    if (url.pathname === '/local-fixture/api/cases' || url.pathname.endsWith('/messages')) {
      const body = JSON.parse(options.body);
      messages = [...messages, { ...reply, id: `msg_local_${messages.length}`, role: 'user', content: body.message ?? body.content, evidence: [] }, reply];
      return Response.json(url.pathname.endsWith('/messages') ? { message: reply } : { case: caseData, snapshot: { id: caseData.snapshotId }, aiMessage: reply });
    }
    if (url.pathname.endsWith('/cas_sample')) return Response.json({ case: caseData, messages });
    if (url.pathname.endsWith('/suggestions')) return Response.json({ id: 'idea_sample' }, { status: 201 });
    return Response.json({ ok: true });
  };
  let widget;
  function mount() {
    if (typeof window.AISupportWidget?.init !== 'function') {
      status.textContent = "विजेट स्क्रिप्ट लोड नहीं हो सकी। SDK URL की जाँच करें और पृष्ठ को पुनः लोड करें।";
      return;
    }
    widget = window.AISupportWidget.init({ apiUrl, tenantKey: tenantId, jwt, context, theme: 'light', locale: locale?.locale });
    document.getElementById('open').disabled = false;
    document.getElementById('reset').disabled = false;
  }
  document.getElementById('open').addEventListener('click', () => { void widget?.open(); });
  document.getElementById('reset').addEventListener('click', () => {
    widget?.destroy();
    messages = [];
    mount();
    if (widget) status.textContent = copy.sampleResetDone ?? "नमूना रीसेट।";
  });
  mount();
})();
